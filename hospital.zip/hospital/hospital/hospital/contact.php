<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <link rel="website icon" href="assets/images/favicon.png">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
     <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />

<style>
    #contact_us h2{
            color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
           text-align: center;
           top: -70px;
           font-size: 50px;
           left: 60px;
           position: relative;
        }
#contact_us{
    position: absolute;
    width: 100%;
    /* top: -700px; */
    z-index: 1;
    left: -900px;
    border: none;
}

 .img{
				/* background-image: url("../hms/assets/images/login2-background.jpg");
				background-repeat: no-repeat;
				background-size: 100%; */
			width: 100%;
			height: 690px;
            /* top: 500px; */
			/* overflow-y: hidden; */
			overflow-x: hidden;
            position: absolute;
		/* border: 3px solid red; */
		    }
        
.img img{
				/* background-image: url("../hms/assets/images/login2-background.jpg");
				background-repeat: no-repeat;
				background-size: 100%; */
			width: 100%;
            position: absolute;
			height: 690px;
			background-clip: contain;
			/* overflow-x: hidden; */
			overflow: auto;
		/* border: 3px solid red; */
		    }
            #contact_us form{
                /* box-shadow: -2px 5px 10px 10px black; */
	/* background: transparent; */
	/* width: 550px; */
	border-radius: 30px;
    top: 100px;
	position: relative;
	/* backdrop-filter: blur(30px) */
            }
            #contact_us form label{
                
                font-size: 25px;
                position: relative;
                left: 20px;
                width: 400px;
               
                color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
            }
            #contact_us form input, textarea{
                /* color: black; */
                /* left: 50px; */
                border-radius: 10px;
                box-shadow:  5px 10px 10px black;
                position: relative;
              
            }
            .btn-box2{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: 250px;
            /* margin-top: -60px;  */
            /* border: 3px solid red; */
            position: relative;
			
        }
        button.btn2 a{
            color: white;
            font-size: 14px;
            font-family: fancy;
            font-weight: bold;
        }
        button.btn2{
            display: inline-flex;
            justify-content: center;
            align-items: center;
            border: none;
            box-shadow: 0 5px 5px 0 rgba(28, 28, 29, 0.65), 0 8px 15px 0 rgba(25, 25, 26, 0.54);
            width: 100px;
            height: 40px;
            background-color: rgb(23, 8, 217);
            color: white;
            font-weight: bold;
            text-decoration: none;
            transition: .6s;
            overflow: hidden;
            /* top: 50px; */
            /* left: -77px; */
            z-index: 1;
            border-radius: 10px;
            font-family: fancy;
            position: relative;
        }
        button.btn2:hover{
            color: black;
        }
        button.btn2::before{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 40px;
            background-color: rgba(101, 92, 232, 0.766);
            transition: 1.3s;
            z-index: -1;
            border-radius: 10px;
        }
        button.btn2:hover::before{
            width: 200px;
        }
        .col-sm-1 .btn {
    margin-left: 50px; /* Adjust the value as needed */
}
form .favicon {
    width: 150px;
    height: 120px;
  
    position: fixed;
    top: 20px; /* Adjust this value as needed to position the favicon vertically */
    left: calc(50% - 235px); /* To center it horizontally */
    z-index: 99;
}

form .favicon img {
    width: 100%;   
    background: none;
    height: 100%;
    object-fit: contain; 
    filter: drop-shadow(
            -3px 5px 1px rgb(103, 144, 203)
            ); 
}



















        @media  (max-width: 856px){
            .img img{
                height: 800px;
            }
            form .favicon {
    width: 150px;
    height: 120px;
  
    position: fixed;
    top: 20px; 
    left: calc(50% - 235px);
    z-index: 99;
}
        }
        @media  (max-width: 576px){
            .img img{
                height: 900px;
            }
            form .favicon {
    width: 150px;
    height: 120px;
    /* Remove position: fixed; */
    /* Keep the rest of the styles */
}

/* Adjust the position as needed */
form .favicon {
    position: absolute;
    top: -90px; /* Adjust this value as needed */
    left: calc(50% - 185px); /* Adjust this value as needed */
    z-index: 99;
}

#contact_us h2{
            color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
           text-align: center;
           top: -70px;
           font-size: 34px;
           left: 60px;
           position: relative;
        }
        }
        @media  (max-width: 292px){
            .img img{
                height: 1000px;
            }
            form .favicon {
            width: 150px;
            height: 120px;
        
            position: fixed;
            top: 20px; 
            left: calc(50% - 235px);
            z-index: 99;
}
        }
        @media  (max-width: 276px){
            .img img{
                height: 1200px;
            }
            form .favicon {
    width: 150px;
    height: 120px;
  
    position: fixed;
    top: 20px; 
    left: calc(50% - 215px);
    z-index: 99;
}
        }
        
       
</style>
</head>
<body>
<section id="contact_us" class="contact-us-single btn-box2">
<div class="img">
<img src="hms/assets/images/bg2.avif" alt="">
    <div class="row no-margin">

        <div  class="col-sm-12 cop-ck">
            <form method="post">
            <h2 >Contact Form</h2>
            <div class="favicon">
                           <img src="hms/assets/images/favicon.png" alt="">
                    </div>
                <div class="row cf-ro">
                    <div  class="col-sm-3"><label>Enter Name :</label></div>
                    <div class="col-sm-8"><input type="text" placeholder="Enter Name" name="fullname" class="form-control input-sm" required ></div>
                </div>
                <div  class="row cf-ro">
                    <div  class="col-sm-3"><label>Email Address :</label></div>
                    <div class="col-sm-8"><input type="text" name="emailid" placeholder="Enter Email Address" class="form-control input-sm"  required></div>
                </div>
                 <div  class="row cf-ro">
                    <div  class="col-sm-3"><label>Mobile Number:</label></div>
                    <div class="col-sm-8"><input type="text" name="mobileno" placeholder="Enter Mobile Number" class="form-control input-sm" required ></div>
                </div>
                 <div  class="row cf-ro">
                    <div  class="col-sm-3"><label>Enter  Message:</label></div>
                    <div class="col-sm-8">
                      <textarea rows="5" placeholder="Enter Your Message" class="form-control input-sm" name="description" required></textarea>
                    </div>
                </div>
                 <div  class="row cf-ro ">
                    <div  class="col-sm-3"><label></label></div>
                    <div class="col-sm-1 ">
                     <button class="btn btn-success btn-sm btn2" type="submit" name="submit">Send Message</button>
                    </div>
            </div>
        </form>
        </div>
 
    </div>
</div>
</section>
</body>
</html>

