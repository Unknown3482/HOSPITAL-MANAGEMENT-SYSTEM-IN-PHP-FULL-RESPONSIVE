
<?php
include_once('hms/include/config.php');
if(isset($_POST['submit']))
{
$name=$_POST['fullname'];
$email=$_POST['emailid'];
$mobileno=$_POST['mobileno'];
$dscrption=$_POST['description'];
$query=mysqli_query($con,"insert into tblcontactus(fullname,email,contactno,message) value('$name','$email','$mobileno','$dscrption')");
echo "<script>alert('Your information succesfully submitted');</script>";
echo "<script>window.location.href ='index.php'</script>";

} ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Hospital management System </title>

    <link rel="website icon" href="assets/images/favicon.png">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
     <link rel="stylesheet" href="assets/css/animate.css">
     <link rel="stylesheet" href="assets/css/reponsive.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
    


    <style>
        *{
            font-family: fancy;
            font-weight: bold;
        }
        html{
            scroll-behavior: smooth;
            /* overflow-x: hidden; */
        }
        body{
            overflow-x: hidden;
        }
        /* <!-- ################# Header Starts Here#######################---> */
        .active{
            /* color: rgb(23, 8, 217); */
            color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
        }
        .header-nav{
            top: 0;
            left: 0;
            position: fixed;
            box-shadow: 10px 10px 10px black;
       
        }
        .header-nav .favicon{
           width: 100px;
           height: 80px;
           /* border: 2px solid red; */
           position: absolute;
           left: 10px;
           top: -8px;
           
        }
        .header-nav .favicon img {
    width: 100px;
    height: 80px;
    background: none;  
    filter: drop-shadow(
            -3px 5px 1px rgb(103, 144, 203)
            ); 
}

        .appoint{
            margin-left: 1100px;
            margin-top: -80px;
            
        }
        #menu  ul li a:hover{ 
            color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
        }
        .nav-item ul {
            margin-left: 100px;
            width: 100%;
            /* border: 3px solid red; */
           
        }
       
        .nav-item ul li a{
            margin-left: -20px;
           /* color: #000; */
           font-size: 20px;
        }
        .btn-box1{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 30px;
            margin-left: 1100px;
            margin-top: -60px; 
            /* border: 3px solid red; */
            position: relative;
        }
        button.btn1 a{
            color: white;
            font-size: 19px;
            font-family: fancy;
            font-weight: bold;
        }
        button.btn1{
            display: inline-flex;
            justify-content: center;
            align-items: center;
            width: 200px;
            height: 40px;
            background-color: rgb(23, 8, 217);
            color: white;
            font-weight: bold;
            text-decoration: none;
            transition: .6s;
            overflow: hidden;
            z-index: 1;
            border-radius: 10px;
            font-family: fancy;
            position: relative;
        }
        button.btn1:hover{
            color: black;
        }
        button.btn1::before{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 40px;
            background-color: rgba(101, 92, 232, 0.766);
            transition: 1.3s;
            z-index: -1;
            border-radius: 10px;
        }
        button.btn1:hover::before{
            width: 200px;
        }

        /* <!-- ################# Slider Starts Here#######################---> */
        .slider-detail .carousel-cover{
            background-color: rgba(43, 34, 160, 0.766);
        }

        
        
        /* <!-- ################# Login Starts Here#######################---> */
        .inner-title h2{
            color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
            font-size:42px;
        }
        .blog-single img{
            box-shadow: 10px 10px 10px black;
            border-radius: 20px;
            transition: all 0.5s;
        }
        .blog-smk:hover .blog-single img{
            margin-top: -70px;
            transition: all 0.5s;
        }
        .blog-smk:hover .blog-single-det{
            margin-top: 50px;
            transition: all 0.5s;
        }
       .blog-smk .blog-single .blog-single-det{
           border-radius: 20px;
           transition: all 0.5s;
           box-shadow: 0 12px 16px 0 rgba(28, 28, 29, 0.65), 0 12px 16px 0 rgba(25, 25, 26, 0.54);
        }
         .text{
           color: #000;
           position: relative;
          text-align: center;
          right: -70px;
        }
        /* .blog-single-det .btn{
            background-color: rgb(23, 8, 217);
            border-radius: 7px;
            box-shadow: 0 5px 5px 0 rgba(28, 28, 29, 0.65), 0 8px 15px 0 rgba(25, 25, 26, 0.54);
        } */
        .btn-box2{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: 1100px;
            margin-top: -60px; 
            /* border: 3px solid red; */
            position: relative;
        }
        button.btn2 a{
            color: white;
            font-size: 14px;
            font-family: fancy;
            font-weight: bold;
        }
        button.btn2{
            display: inline-flex;
            justify-content: center;
            align-items: center;
            border: none;
            box-shadow: 0 5px 5px 0 rgba(28, 28, 29, 0.65), 0 8px 15px 0 rgba(25, 25, 26, 0.54);
            width: 100px;
            height: 40px;
            background-color: rgb(23, 8, 217);
            color: white;
            font-weight: bold;
            text-decoration: none;
            transition: .6s;
            overflow: hidden;
            top: 50px;
            left: -77px;
            z-index: 1;
            border-radius: 10px;
            font-family: fancy;
            position: relative;
        }
        button.btn2:hover{
            color: black;
        }
        button.btn2::before{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 40px;
            background-color: rgba(101, 92, 232, 0.766);
            transition: 1.3s;
            z-index: -1;
            border-radius: 10px;
        }
        button.btn2:hover::before{
            width: 200px;
        }


        /* <!-- ################# Our Departmentn  Starts Here#######################---> */
        .inner-title p{
            color: #000;
            font-size: 20px;
        }
        .department .single-key i{
            color: rgb(23, 8, 217);
            
        }
        .department h5{
            color: #000;
        }



        /* <!-- ################# About  Starts Here#######################---> */
        .about-us h3{
            color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
            font-size:42px;
            margin-left: 30px;
        }
        
        .about-us .image-bg{
            border-radius: 20px;
            
            transition: 0.3s;
            z-index: 99;
            box-shadow: 0 10px 15px 0 rgba(28, 28, 29, 0.65), 0 10px 15px 0 rgba(25, 25, 26, 0.54);
        }
        .about-us .image-bg:hover{
            transform: scale(1.2);
        }





 /* <!-- ################# Gallery  Starts Here#######################---> */


        .filter-button:hover {
            background-color: rgb(23, 8, 217);
        }
        .gallery_product{
            margin-top: 30px;
        }
        .gallery-filter {
            width: 70%;
            text-align: center;
            margin-left: 200px;
            
        }
        .gallery-filter .btn-box3{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            /* margin-left: 1100px; */
            margin-top: -60px; 
            border: none;
            /* border: 3px solid red; */
            position: relative;
        }
       
        .gallery-filter {
    width: 100%;
    text-align: center;
    margin-top: -70px;
    margin-left: 100px;
    /* Remove absolute positioning */
}





        .gallery_product{
            overflow: hidden;
        }
        .gallery_product img{
            transition: 0.6s;
            cursor: pointer;
            border-radius: 20px;
            box-shadow: 10px 10px 10px  black; 
        }
        .gallery_product img:hover{
            transform: scale(1.3);
        }



        .btn-boxg{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: 1100px;
            margin-top: -60px; 
            /* border: 3px solid red; */
            position: relative;
        }
        button.btng a{
            color: white;
            font-size: 14px;
            font-family: fancy;
            font-weight: bold;
        }
        button.btng{
            display: inline-flex;
            justify-content: center;
            align-items: center;
            border: none;
            box-shadow: 0 5px 5px 0 rgba(28, 28, 29, 0.65), 0 8px 15px 0 rgba(25, 25, 26, 0.54);
            width: 100px;
            height: 40px;
            background-color: rgb(23, 8, 217);
            color: white;
            font-weight: bold;
            text-decoration: none;
            transition: .6s;
            overflow: hidden;
            top: 50px;
            left: -77px;
            z-index: 1;
            border-radius: 10px;
            font-family: fancy;
            position: relative;
        }
        button.btng:hover{
            color: black;
        }
        button.btng::before{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 40px;
            background-color: rgba(101, 92, 232, 0.766);
            transition: 1.3s;
            z-index: -1;
            border-radius: 10px;
        }
        button.btng:hover::before{
            width: 200px;
        }
        .gallery-filter .btn {
    background-color: rgb(23, 8, 217); }
    

.gallery-filter .btn {
    margin: 0 5px; /* Add some margin between buttons */
}

        

    /* <!-- ################# Contact  Starts Here#######################---> */
    #contact{
        height: 600px;
    }
    .contact-us-single h2{
            color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
           text-align: center;
           top: 70px;
           left: -300px;
           position: relative;
        }
    .cop-ck{
        text-align: center;
        width: 700px;
       
        height: 600px;
        left: -600px;
        /* border: 3px solid red; */
       }

.ib {
            position: relative;
            width: 100%;
            height: 50px;
            margin-top: 110px;
            margin-bottom: -110px;
            margin-left: -500px;
            /* border: 3px solid red; */
        }
      
       
       
        
      

        .ib input,
     .ib textarea {
            width: 600px;
            height: 30px;
            margin-bottom: 5px; 
            position: absolute;
            margin-top: 15px;
            margin-left: -70px; 
            background: transparent;
            outline: none;
            border: none;
            /* border: 3px solid red; */
            border-bottom: 2px solid;
        }

 .ib textarea {
            height: 120px; 
            resize: none;
        }
        
       .ib label {
            color: #000;
            position: absolute;
            margin-top: 15px;
            margin-left: -70px; 
            pointer-events: none;
            transition: 0.3s ease all; 
            /* border: 3px solid red; */
        }

          .ib input:focus ~ label,
          .ib input:valid ~ label,
          .ib textarea:focus ~ label,
          .ib textarea:valid ~ label,
          .ib textarea:not(:placeholder-shown) ~ label {
            top: -20px;
            font-size: 12px; 
            color: #999;
        }
       /* .btn-sm{
        margin-left: -300px;
        margin-top: 240px;
       font-weight: bold;
       
       } */
        .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            /* margin-left: 1100px; */
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
      
        button.subbtn{
            display: inline-flex;
            justify-content: center;
            align-items: center;
            border: none;
            box-shadow: 0 5px 5px 0 rgba(28, 28, 29, 0.65), 0 8px 15px 0 rgba(25, 25, 26, 0.54);
            width: 150px;
            height: 40px;
            background-color: rgb(23, 8, 217);
            color: white;
            font-weight: bold;
            text-decoration: none;
            transition: .6s;
            overflow: hidden;
            top: 50px;
            left: -77px;
            z-index: 1;
            margin-left: 0px;
            border-radius: 10px;
            font-family: fancy;
            position: relative;
        }
        button.subbtn:hover{
            color: black;
        }
        button.subbtn::before{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 40px;
            background-color: rgba(101, 92, 232, 0.766);
            transition: 1.3s;
            z-index: -1;
            border-radius: 10px;
        }
        button.subbtn:hover::before{
            width: 150px;
            
        }
        .subbtn {
            background-color: rgb(23, 8, 217);
            width: 200px;
            position: absolute;
        }
        /* <!-- ################# Footer  Starts Here#######################---> */
       .footer h2{
        color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
            font-size:42px;
       }
       .footer address{
        margin-top: 30px;
        margin-bottom: -130px;
       }
       .copy {
        text-align: center;
       }

       /* Style for active link */
.header-nav ul li.active a {
    color: red; /* Change color as per your preference */
} 
.btn-boxham{
    display: none;
}













    @media(max-width: 2560px) {
    .contact-us-single h2 {
        left: -300px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -120px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
}

@media(max-width: 1440px){
    .header-nav{
        top: 0;
    }
   
    .contact-us-single h2 {
        left: -300px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -120px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
  
    .btn-box1{
        margin-left: 900px;
    }
    .carousel-inner {
        /* border: 3px solid red; */
    position: relative;
   width: 1434px;
    margin-top: 100px;
 }
}
@media(max-width: 1280px){
    .header-nav{
        top: 0;
    }
    .container span{
        position: absolute;
        /* color: #000; */
        margin-left: 60px;
    }
   .header-nav .favicon{
           width: 100px;
           height: 80px;
           /* border: 2px solid red; */
           position: absolute;
           left: 70px;
           top: -8px;
           
        }
    .contact-us-single h2 {
        left: -300px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -120px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .btn-box1{
        margin-left: 970px;
        /* border: 3px solid red; */
    }
    .footer {

        width: 1260px;
    }
    .copy {
        width: 1260px;
    }
    .carousel-inner {
    position: relative;
   width: 1260px;
    margin-top: 90px;
 }
}
@media(max-width: 1200px){
    .header-nav{
        position: fixed;
        top: 0;
    }
    .header-nav .favicon{
           width: 100px;
           height: 80px;
           /* border: 2px solid red; */
           position: absolute;
           left: 80px;
           top: -8px;
           
        }
    

    .container span{
        position: absolute;
        /* color: #000; */
        margin-left: 70px;
    }
    .contact-us-single h2 {
        left: -300px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -120px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
  
    .btn-box1{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 30px;
            margin-left: 950px;
            margin-top: -60px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .nav-item ul{
            margin-left: 100px;
            width: 120%;
            display: flex;
            /* border: 3px solid red; */
           
        }
        .nav-item ul li{
            margin-left: 10px;
        }
        .gallery-filter {
             margin-left: 180px;
        }
        .footer {
                width: 1180px;
            }
        .copy{
                width: 1180px;
            }
        .carousel-inner {
                position: relative;
                width: 1180px;
                margin-top: 90px;
        }
 
}

@media(max-width: 1196px){
   .header-nav{
        height: 90px;
    }
    .header-nav .favicon{
           width: 100px;
           height: 80px;
           /* border: 2px solid red; */
           position: absolute;
           left: 140px;
           top: -8px;
           
        }
    .container span{
        position: absolute;
        /* color: #000; */
        margin-left: 130px;
    }
    .carousel-inner {
        position: relative;
        width: 1177px;
        margin-top: 100px;
    }
    .nav-item ul{
            margin-left: 200px;
            width: 100%;
            text-align: center;
            top: 5px;
            left: -10px;
            position: relative;
            /* display: flex; */
            /* border: 3px solid red; */
           
        }
        .nav-item ul li{
            margin-left: 50px;
        }
       
        .carousel-indicators .active{
            color: #000;
            
        }
        .footer {
                width: 1270px;
            }
        .copy{
                width: 1270px;
            }
        .carousel-inner {
                position: relative;
                width: 1270px;
                margin-top: 70px;
        }
        .btn-box1{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 30px;
            margin-left: 1100px;
            margin-top: -60px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .blog-single-det .text{
          right: 50px;
          position: absolute;
         
        }
        button.btn2{
           left: 40px;
        }
        .contact-us-single h2{
        margin-left: -800px;
    }
    .contact-us-single h2{
        margin-left: -800px;
    }
    .contact-us-single h2 {
        left: 100px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -120px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .ib{
        margin-left: -500px;
        }
    .btn-box{
        margin-left: -870px; 
    }
}
@media(max-width: 1024px){
    .container span{
        position: absolute;
        /* color: #000; */
        margin-left: 100px;
    }
    .carousel-inner {
        position: relative;
        width: 1177px;
        margin-top: 100px;
    }
    .nav-item ul{
            margin-left: 100px;
            width: 120%;
            /* display: flex; */
            /* border: 3px solid red; */
           
        }
        .nav-item ul li{
            margin-left: 40px;
        }
       
        .carousel-indicators .active{
            color: #000;
            
        }
        .footer {
                width: 1100px;
            }
        .copy{
                width: 1100px;
            }
        .carousel-inner {
                position: relative;
                width: 1100px;
                margin-top: 90px;
        }
        .header-nav .favicon{
           width: 100px;
           height: 80px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: -8px;
           
        }
        .btn-box1{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 30px;
            margin-left: 800px;
            margin-top: -60px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .blog-single-det .text{
          right: 50px;
          position: absolute;
         
        }
        button.btn2{
           left: 40px;
        }
        .contact-us-single h2 {
        left: 240px;
    }
    .cop-ck {
        width: 400px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -60px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
    .ib{
    margin-left: -350px
    }
}
@media(max-width: 996px){
    .container span{
        position: absolute;
        /* color: #000; */
        margin-left: 100px;
    }
    .carousel-inner {
        position: relative;
        width: 1177px;
        margin-top: 100px;
    }
    .nav-item ul{
            margin-left: 100px;
            width: 120%;
            /* display: flex; */
            /* border: 3px solid red; */
           
        }
        .nav-item ul li{
            margin-left: 60px;
        }
       
        .carousel-indicators .active{
            color: #000;
            
        }
        .footer {
                width: 1100px;
            }
        .copy{
                width: 1100px;
            }
        .carousel-inner {
                position: relative;
                width: 1100px;
                margin-top: 90px;
        }
        .header-nav .favicon{
           width: 100px;
           height: 80px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: -8px;
           
        }
        .btn-box1{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 30px;
            margin-left: 780px;
            margin-top: -60px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .blog-single-det .text{
          right: 50px;
          position: absolute;
         
        }
        button.btn2{
           left: 40px;
        }
        .contact-us-single h2 {
        left: 240px;
    }
    .cop-ck {
        width: 400px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -60px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
    .ib{
    margin-left: -350px
    }
}
@media(max-width: 988px){
    .container span{
        position: absolute;
        /* color: #000; */
        margin-left: 100px;
    }
    .carousel-inner {
        position: relative;
        width: 1177px;
        margin-top: 100px;
    }
    .nav-item ul{
            margin-left: 10px;
            width: 120%;
            /* display: flex; */
            /* border: 3px solid red; */
           
        }
        .nav-item ul li{
            margin-left: 60px;
        }
       
        .carousel-indicators .active{
            color: #000;
            
        }
        .footer {
                width: 1100px;
            }
        .copy{
                width: 1100px;
            }
        .carousel-inner {
                position: relative;
                width: 1100px;
                margin-top: 90px;
        }
        .header-nav .favicon{
           width: 100px;
           height: 80px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: -8px;
           
        }
        .btn-box1{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 30px;
            margin-left: 760px;
            margin-top: -60px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .blog-single-det .text{
          right: 50px;
          position: absolute;
         
        }
        button.btn2{
           left: 40px;
        }
        .contact-us-single h2 {
        left: 240px;
    }
    .cop-ck {
        width: 400px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -60px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
    .ib{
    margin-left: -350px
    }
}

@media(max-width: 900px){
   .header-nav{
        height: 150px;
    }
    .container span{
        position: absolute;
        /* color: #000; */
        margin-left: 130px;
    }
    .carousel-inner {
        position: relative;
        width: 1177px;
        margin-top: 100px;
    }
    .nav-item ul{
            margin-left: 100px;
            width: 100%;
            text-align: center;
            top: 60px;
            left: -90px;
            position: relative;
            /* display: flex; */
            /* border: 3px solid red; */
           
        }
        .header-nav .favicon{
           width: 100px;
           height: 80px;
           /* border: 2px solid red; */
           position: absolute;
           left: 140px;
           top: -8px;
           
        }
        .nav-item ul li{
            margin-left: 80px;
        }
       
        .carousel-indicators .active{
            color: #000;
            
        }
        .footer {
                width: 880px;
            }
        .copy{
                width: 880px;
            }
        .carousel-inner {
                position: relative;
                width: 880px;
                margin-top: 160px;
        }
        .btn-box1{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 30px;
            margin-left: 650px;
            margin-top: -70px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .blog-single-det .text{
          right: 50px;
          position: absolute;
         
        }
        button.btn2{
           left: 40px;
        }
        .contact-us-single h2{
        margin-left: -800px;
    }
    .contact-us-single h2{
        margin-left: -800px;
    }
    .contact-us-single h2 {
        left: 100px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -120px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .ib{
        margin-left: -500px;
        }
    .btn-box{
        margin-left: -870px; 
    }
}
@media(max-width: 832px){
   .header-nav{
        height: 150px;
    }
    .container span{
        position: absolute;
        /* color: #000; */
        margin-left: 130px;
    }
    .carousel-inner {
        position: relative;
        width: 1177px;
        margin-top: 100px;
    }
    .nav-item ul{
            margin-left: 100px;
            width: 100%;
            top: 60px;
            text-align: center;
            left: -130px;
            position: relative;
            /* display: flex; */
            /* border: 3px solid red; */
           
        }
        .nav-item ul li{
            margin-left: 80px;
        }
       
        .carousel-indicators .active{
            color: #000;
            
        }
        .footer {
                width: 810px;
            }
        .copy{
                width: 810px;
            }
        .carousel-inner {
                position: relative;
                width: 810px;
                margin-top: 160px;
        }
        .btn-box1{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 30px;
            margin-left: 580px;
            margin-top: -70px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .blog-single-det .text{
          right: 50px;
          position: absolute;
         
        }
        button.btn2{
           left: 40px;
        }
        .contact-us-single h2{
        margin-left: -800px;
    }
    .contact-us-single h2 {
        left: 100px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -120px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
    #contact_us .subbtn {
        width: 130px;
    }
    .btn-box{
        margin-left: -770px; 
    }
    .blog-single-det .text{
          right: 40px;
          position: absolute;
         
        }
        button.btn2{
           left: 30px;
        }
}
@media(max-width: 820px){
   
    .carousel-inner {
        position: relative;
        width: 1177px;
        margin-top: 100px;
    }
    
        .footer {
                width: 800px;
            }
        .copy{
                width: 800px;
            }
        .carousel-inner {
                position: relative;
                width: 800px;
                margin-top: 160px;
        }
        
        
        
}
@media(max-width: 800px){
   
   .carousel-inner {
       position: relative;
       width: 1177px;
       margin-top: 100px;
   }
   
       .footer {
               width: 780px;
           }
       .copy{
               width: 780px;
           }
       .carousel-inner {
               position: relative;
               width: 780px;
               margin-top: 160px;
               
       }
       .btn-box1{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 30px;
            margin-left: 55 0px;
            margin-top: -70px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .blog-single-det .text{
          right: 35px;
          position: absolute;
         
        }
        button.btn2{
           left: 25px;
        }
        .contact-us-single h2{
        margin-left: -800px;
    }
    .contact-us-single h2 {
        left: 100px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -120px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
}
@media (max-width: 764px) {
    header .header-nav {
        background-color: #FFF;
        height: 76px;
        width: 100%;
        z-index: 99;
    }

    .container a i {
        /* border: 3px solid red; */
        margin-top: 15px;
        left: 70px;
        position: relative;
    }

    .carousel-inner {
        position: relative;
        width: 100%; 
        margin-top: 100px;
        
    }
    .footer{
        height: 600px;
    }
    .footer,
    .copy {
        width: 100%; 
    }

    .carousel-inner {
        position: relative;
        width: 100%; 
        margin-top: 80px;
    }
    .slider-detail .carousel-cover {
        display: block; 
    } 

    .btn-box1 {
        display: flex;
        justify-content: space-between;
        width: 300px;
        height: 30px;
        margin: -40px auto 0; 
        position: relative;
    }

    .blog-single-det .text {
        right: 35px;
        position: absolute;

    }

    button.btn2 {
        left: 25px;
    }

    .contact-us-single h2{
        margin-left: -800px;
    }
    .contact-us-single h2 {
        left: 100px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: -120px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
        .ib{
            margin-left: -500px;
        }
    .btn-box{
        margin-left: -870px; 
    }
    .header-nav .btn-boxham{
            display: flex;
            justify-content: space-between;
            width: 350px;
            height: 130px;
            color: white;
            margin-left: 370px;
            margin-top: 170px; 
            border: none;
            /* border: 3px solid red; */
            position: relative;
        }
        button.btnham a{
            color: white;
        }
      
        button.btnham{
            display: inline-flex;
            justify-content: center;
            align-items: center;
            border: none;
            box-shadow: 0 5px 5px 0 rgba(28, 28, 29, 0.65), 0 8px 15px 0 rgba(25, 25, 26, 0.54);
            width: 200px;
            color: white;
            height: 40px;
            background-color: rgb(23, 8, 217);
            /* color: white; */
            font-weight: bold;
            text-decoration: none;
            transition: .6s;
            overflow: hidden;
            top: -150px;
            left: -77px;
            z-index: 1;
            /* margin-left: 250px; */
            border-radius: 10px;
            font-family: fancy;
            position: relative;
        }
        button.btnham:hover{
            color: black;
        }
        button.btnham::before{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 40px;
            background-color: rgba(101, 92, 232, 0.766);
            transition: 1.3s;
            z-index: -1;
            border-radius: 10px;
        }
        button.btnham:hover::before{
            width: 200px;
        }
        .btn-box1{
            display: none;
        }

    header .header-nav .nav-item ul {
        display: block; 
        height: 450px;
        box-shadow: 10px 10px 10px black;
        top: 25px;
        /* z-index: 1; */
        width: 105%;
        /* padding-left: 20px;  */
        background-color: white;
        
    }

    header .header-nav .nav-item ul li {
        display: block; 
        border-top: 1px solid #CCC;
        /* color: white; */
        padding: 14px;
    }
    header .header-nav .nav-item ul li a{
        margin-left: 0px;
        /* color: white; */
    }
   
    .blog-single-det .text{
          right: 30px;
          position: absolute;
         
        }
        button.btn2{
           left: 20px;
        }
      
      
    .gallery-filter {
    width: 100%;
    text-align: center;
    margin-top: -90px;
    margin-left: 160px;
    
}
}
@media (max-width: 540px) {
    .blog-single-det .text{
          left: 20px;
          position: absolute;
         
        }
        button.btn2{
           left: 140px;
        }
}

@media (max-width: 432px) {
    header .header-nav {
        background-color: #FFF;
        height: 76px;
        width: 100%;
        z-index: 99;
    }
 header .header-nav {
        background-color: #FFF;
        height: 86px;
        width: 100%;
        z-index: 99;
    }
     .header-nav .favicon{
           width: 100px;
           height: 65px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: -3px;
           
        }
        .blog-smk .blog-single .blog-single-det .text{
          left: 40px;
          position: absolute;
         
        }
        button.btn2{
           left: 90px;
        }
    .container a i {
        /* border: 3px solid red; */
        margin-top: 15px;
        left: 70px;
        position: relative;
    }

    .carousel-inner {
        position: relative;
        width: 100%; 
        margin-top: 100px;
        
    }
    .footer{
        height: 600px;
    }
    .footer,
    .copy {
        width: 100%; 
    }

    .carousel-inner {
        position: relative;
        width: 100%; 
        margin-top: 84px;
    }
    .slider-detail .carousel-cover {
        display: block; 
    } 
    .slider-detail .carousel-cover {
        transform: rotate(14deg);
        top: -50px; 
        left: -140px;
}
}
@media (max-width: 428px) {
    header .header-nav {
        background-color: #FFF;
        height: 76px;
        width: 100%;
        z-index: 99;
    }
 header .header-nav {
        background-color: #FFF;
        height: 86px;
        width: 100%;
        z-index: 99;
    }
     .header-nav .favicon{
           width: 100px;
           height: 65px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: -3px;
           
        }
    .container a i {
        /* border: 3px solid red; */
        margin-top: 15px;
        left: 70px;
        position: relative;
    }

    .carousel-inner {
        position: relative;
        width: 100%; 
        margin-top: 100px;
        
    }
    .footer{
        height: 600px;
    }
    .footer,
    .copy {
        width: 100%; 
    }

    .carousel-inner {
        position: relative;
        width: 100%; 
        margin-top: 84px;
    }
    .slider-detail .carousel-cover {
        display: block; 
    } 
    .slider-detail .carousel-cover {
        transform: rotate(14deg);
        top: -50px; 
        left: -140px;
} 
    .btn-box1 {
        display: flex;
        justify-content: space-between;
        width: 300px;
        height: 30px;
        margin: -40px auto 0; 
        position: relative;
    }

    .blog-single-det .text {
        right: 35px;
        position: absolute;

    }

    button.btn2 {
        left: 25px;
    }

  
    .contact-us-single h2 {
        left: 100px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
        
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: 40px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
    .ib{
        
        margin-left: -400px; 
    }
.ib input{
    width: 350px;
}
.ib textarea{
    width: 350px;
}
    #contact_us .subbtn {
        width: 130px;
    }

    .btn-box {
        margin-left: -520px;
    }
    .header-nav .btn-boxham{
            display: flex;
            justify-content: space-between;
            width: 350px;
            height: 130px;
            color: white;
            margin-left: 370px;
            margin-top: 170px; 
            border: none;
            /* border: 3px solid red; */
            position: relative;
        }
        button.btnham a{
            color: white;
        }
      
        button.btnham{
            display: inline-flex;
            justify-content: center;
            align-items: center;
            border: none;
            box-shadow: 0 5px 5px 0 rgba(28, 28, 29, 0.65), 0 8px 15px 0 rgba(25, 25, 26, 0.54);
            width: 200px;
            color: white;
            height: 40px;
            background-color: rgb(23, 8, 217);
            /* color: white; */
            font-weight: bold;
            text-decoration: none;
            transition: .6s;
            overflow: hidden;
            top: -150px;
            left: -77px;
            z-index: 1;
            /* margin-left: 250px; */
            border-radius: 10px;
            font-family: fancy;
            position: relative;
        }
        button.btnham:hover{
            color: black;
        }
        button.btnham::before{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 0;
            height: 40px;
            background-color: rgba(101, 92, 232, 0.766);
            transition: 1.3s;
            z-index: -1;
            border-radius: 10px;
        }
        button.btnham:hover::before{
            width: 200px;
        }
        .btn-box1{
            display: none;
        }

    header .header-nav .nav-item ul {
        display: block; 
        height: 450px;
        box-shadow: 10px 10px 10px black;
        top: 25px;
        /* z-index: 1; */
        width: 105%;
        /* padding-left: 20px;  */
        background-color: white;
        
    }

    header .header-nav .nav-item ul li {
        display: block; 
        border-top: 1px solid #CCC;
        /* color: white; */
        padding: 14px;
    }
    header .header-nav .nav-item ul li a{
        margin-left: 0px;
        /* color: white; */
    }
   
    .blog-single-det .text{
          right: 105px;
          position: absolute;
         
        }
        button.btn2{
           left: 90px;
        }
        .about-us h3{
            color: rgb(6, 84, 194);
            text-shadow:  -5px 2px 3px rgb(103, 145, 204),
                         -5px 5px 10px rgba(28, 49, 79, 0.822),
                         -5px 5px 10px rgb(14, 41, 80);
            font-weight:bold;
            font-size:42px;
            text-align: center;
            width: 300px;
            margin-left: 10px;
        }
        .our-blog .blog-single {
    text-align: center;
    margin-top: 20px;
    
    margin-bottom: 80px; }
  
    .about-us .image-bg {
        display: block;
        width: 360px;
        left: 25px;
        height: 300px;
  background-image: url(../images/why.jpg);
  background-size: contain; }
    
        .about-us .image-bg:hover{
            transform: scale(1.1);
        }
        .header-nav .btn-boxham{
            margin-left: 190px;
        }
}
@media (max-width: 416px){
    .contact-us-single h2 {
        left: 100px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
        
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: 40px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
    .ib{
        
        margin-left: -400px; 
    }
.ib input{
    width: 350px;
}
.ib textarea{
    width: 350px;
}
    #contact_us .subbtn {
        width: 130px;
        
    }

    .btn-box {
        margin-left: -420px;
    }
     header .header-nav {
        background-color: #FFF;
        height: 86px;
        width: 100%;
        z-index: 99;
    }
     .header-nav .favicon{
           width: 100px;
           height: 65px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: -3px;
           
        }
}
    
@media (max-width: 396px){
    .contact-us-single h2 {
        left: 100px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
        
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: 40px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
    .ib{
        
        margin-left: -380px; 
    }
.ib input{
    width: 320px;
}
.ib textarea{
    width: 320px;
}
    #contact_us .subbtn {
        width: 130px;
    }

    .btn-box {
        margin-left: -420px;
    }
    .blog-single-det .text{
          right: 90px;
          position: absolute;
         
        }
        button.btn2{
           left: 80px;
        }
         header .header-nav {
        background-color: #FFF;
        height: 86px;
        width: 100%;
        z-index: 99;
    }
     .header-nav .favicon{
           width: 100px;
           height: 65px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: -3px;
           
        }
}
@media (max-width: 376px){
    header .header-nav {
        background-color: #FFF;
        height: 86px;
        width: 100%;
        z-index: 99;
    }
     .header-nav .favicon{
           width: 100px;
           height: 65px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: -3px;
           
        }
    .about-us .image-bg {
        display: block;
        width: 310px;
        left: 25px;
        height: 300px;
  background-image: url(../images/why.jpg);
  background-size: contain; }
  .contact-us-single h2 {
        left: 100px;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
        
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: 40px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
    .ib{
        
        margin-left: -380px; 
    }
.ib input{
    width: 320px;
}
.ib textarea{
    width: 320px;
}
    #contact_us .subbtn {
        width: 130px;
    }

    .btn-box {
        margin-left: -400px;
    }
    .blog-single-det .text{
          right: 80px;
          position: absolute;
         
        }
        button.btn2{
           left: 70px;
        }
        .about-us .abut-yoiu {
  padding: 50px;
  left: -20px;
  background-color: #FFF; }
}
    

@media (max-width: 360px){
 
    .about-us .image-bg {
        display: block;
        width: 300px;
        left: 23px;
        height: 300px;
  background-image: url(../images/why.jpg);
  background-size: contain; }
  .contact-us-single h2 {
        left: 100px;
    }
    .header-nav .favicon{
           width: 100px;
           height: 65px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: -3px;
           
        }
          header .header-nav {
        background-color: #FFF;
        height: 86px;
        width: 100%;
        z-index: 99;
    }
    .cop-ck {
        width: 700px;
        position: absolute;
        height: 600px;
        left: calc(50% - 50px); /* Centering horizontally */
        /* border: 3px solid red; */
    }
    .btn-subbtn{
        
            display: flex;
            justify-content: space-between;
            width: 300px;
            height: 130px;
            margin-left: 40px;
            border: none;
            margin-top: 170px; 
            /* border: 3px solid red; */
            position: relative;
        }
    .btn-box{
        margin-left: -870px; 
    }
    .ib{
        
        margin-left: -390px; 
    }
.ib input{
    width: 310px;
}
.ib textarea{
    width: 310px;
}
    #contact_us .subbtn {
        width: 130px;
    }

    .btn-box {
        margin-left: -400px;
    }
    .blog-single-det .text{
          right: 70px;
          position: absolute;
         
        }
        button.btn2{
           left: 65px;
        }
        .about-us .abut-yoiu {
  padding: 50px;
  left: -20px;
  background-color: #FFF; 
}
.header-nav .btn-boxham{
            margin-left: 140px;
        }
}
    
@media (max-width: 320px){
   
    .contact-us-single h2 {
        margin-left: -230px;
        width: 310px;
        /* border: 3px solid red; */
    }
    .header-nav .favicon{
           width: 100px;
           height: 70px;
           /* border: 2px solid red; */
           position: absolute;
           left: 110px;
           top: 0px;
           
        }
    .about-us .image-bg {
        display: block;
        width: 255px;
        left: 25px;
        height: 300px;
  background-image: url(../images/why.jpg);
  background-size: contain; }

    .blog-single-det .text{
          right: 50px;
          position: absolute;
         
        }
        button.btn2{
           left: 50px;
        }
        .about-us .abut-yoiu h3{
            left: -50px;
            position: relative;;
        }
        .about-us .abut-yoiu {
  padding: 50px;
  left: -20px;
  background-color: #FFF;
 }
 .header-nav .btn-boxham{
            margin-left: 120px;
        }

}
    




    </style>
</head>

    <body>

    <!-- ################# Header Starts Here#######################--->
<header id="menu-jk">
   
    <div id="nav-head" class="header-nav">
        <div class="container">
            <div class="row">   
                <div class="col-lg-2 col-md-3  col-sm-12" style=" color: rgb(6, 84, 194);  text-shadow: -5px 2px 3px rgb(103, 145, 204),
                -5px 5px 10px      rgba(28, 49, 79, 0.822),
                -5px 5px 10px      rgb(14, 41, 80); font-weight:bold; font-size:42px; margin-left: -100px; margin-top: 1% !important; 
                    ">
                    <!-- <span class="logo">HMS</span> -->
                    <div class="favicon">
                           <img src="../hospital/assets/images/favicon.png" alt="">
                    </div>
                   <a data-toggle="collapse" data-target="#menu" href="#menu" ><i  class="fas d-block d-md-none small-menu fa-bars"></i></a>
                </div>
                <div id="menu" class="col-lg-8 col-md-9 d-none d-md-block nav-item">
                <ul>
                    <li><a href="#" class="menu-item active">Home</a></li>
                    <li><a href="#services" class="menu-item">Services</a></li>
                    <li><a href="#about_us" class="menu-item">About Us</a></li>
                    <li><a href="#gallery" class="menu-item">Gallery</a></li>
                    <li><a href="../hospital/contact.php" class="menu-item">Contact Us</a></li>
                    <li><a href="#logins" class="menu-item">Logins</a></li>  


                    <div class="btn-boxham">
                    <button  class="btnham">
                        <a href="hms/user-login.php">Book an Appointment</a>
                    </button>
                </div>
                </ul>
            </div>
                <!-- <div class="col-sm-2 d-none d-lg-block appoint">
                    <button class="btn1">

                        <a class="btn btn-success" href="hms/user-login.php">Book an Appointment</a>
                    </button>
                </div> -->
                <div class="btn-box1">
                    <button  class="btn1">
                        <a href="hms/user-login.php">Book an Appointment</a>
                    </button>
                </div>
            </div>
           
        </div>
    </div>
</header>

    
    
    <!-- ################# Slider Starts Here#######################--->
    <div class="slider-detail">

        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            </ol>


   


            <div class="carousel-inner">
                <div class="carousel-item ">
                    <img class="d-block w-100" src="assets/images/slider/slider_2.jpg" alt="Second slide">
                    <div class="carousel-cover"></div>
                    <div class="carousel-caption vdg-cur d-none d-md-block">
                        <h5 class="animated bounceInDown">Hospital Management System</h5>
            
                         
                    
                    </div>
                </div>
                
                <div class="carousel-item active">
                    <img class="d-block w-100" src="assets/images/slider/slider_3.jpg" alt="Third slide">
                      <div class="carousel-cover"></div>
                    <div class="carousel-caption vdg-cur d-none d-md-block">
                        <h5 class="animated bounceInDown">Hospital Management System</h5>
            
                         
                    
                    </div>
              
                </div>
                
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>


    </div>
    
  <!--  ************************* Logins ************************** -->
    
    
     <section id="logins" class="our-blog container-fluid">
        <div class="container">
        <div class="inner-title">

                <h2>Logins</h2>
            </div>
            <div class="col-sm-12 blog-cont">
                <div class="row no-margin">
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img  src="assets/images/patient.jpg" alt="">

                            <div class="blog-single-det btn-box2">
                                <h6 class="text">Patient Login</h6>
                                <!-- <a href="hms/user-login.php" target="_blank">
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a> -->


                                   <!-- <div class="btn-box2" > -->
                                        <button  class="btn2">
                                            <a href="hms/user-login.php" target="_blank">Click Here</a>
                                        </button>
                                    <!-- </div> -->
                                
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">
                                   
                                <img src="assets/images/doctor.jpg" alt="">

                            <div class="blog-single-det btn-box2">
                                <h6 class="text">Doctors login</h6>
                                <!-- <a href="hms/doctor" target="_blank">
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a> -->

                                <button  class="btn2">
                                    <a href="hms/user-login.php" target="_blank">Click Here</a>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets/images/admin.jpg" alt="">

                            <div class="blog-single-det btn-box2">
                                <h6 class="text">Admin Login</h6>
                    
                                <!-- <a href="hms/admin" target="_blank">
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a> -->

                                <button  class="btn2">
                                    <a href="hms/user-login.php" target="_blank">Click Here</a>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    
                    

                    
                    
                </div>
            </div>
            
        </div>
    </section>  







    <!-- ################# Our Departments Starts Here#######################--->


    <section id="services" class="key-features department">
        <div class="container">
            <div class="inner-title">

                <h2>Our Key Features</h2>
                <p>Take a look at some of our key features</p>
            </div>

            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="single-key">
                        <i class="fas fa-heartbeat"></i>
                        <h5>Cardiology</h5>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-key">
                        <i class="fas fa-ribbon"></i>
                        <h5>Orthopaedic</h5>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-key">
                       <i class="fab fa-monero"></i>
                        <h5>Neurologist</h5>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-key">
                        <i class="fas fa-capsules"></i>
                        <h5>Pharma Pipeline</h5>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="single-key">
                        <i class="fas fa-prescription-bottle-alt"></i>
                        <h5>Pharma Team</h5>
                    </div>
                </div>



                <div class="col-lg-4 col-md-6">
                    <div class="single-key">
                        <i class="far fa-thumbs-up"></i>
                        <h5>High Quality treatments</h5>

                    </div>
                </div>
            </div>






        </div>

    </section>
    
    
  
    
    <!--  ************************* About Us Starts Here ************************** -->
        
    <section id="about_us" class="about-us">
        <div class="row no-margin">
            <div class="col-sm-6 image-bg no-padding">
                
            </div>
            <div class="col-sm-6 abut-yoiu">
                <h3>About Our Hospital</h3>
<?php
$ret=mysqli_query($con,"select * from tblpage where PageType='aboutus' ");
while ($row=mysqli_fetch_array($ret)) {
?>

    <p><?php  echo $row['PageDescription'];?>.</p><?php } ?>
            </div>
        </div>
    </section>    
    
    
            <!--  ************************* Gallery Starts Here ************************** -->
        <div id="gallery" class="gallery  .btn-boxg">    
           <div class="container">
              <div class="inner-title">

                <h2>Our Gallery</h2>
                <p>View Our Gallery</p>
            </div>
              <div class="row">
                

        <div class="gallery-filter d-none d-sm-block">
            <button class="btn btn-default filter-button btng" data-filter="all">All</button>
            <button class="btn btn-default filter-button btng" data-filter="hdpe">Dental</button>
            <button class="btn btn-default filter-button btng" data-filter="sprinkle">Cardiology</button>
            <button class="btn btn-default filter-button btng" data-filter="spray"> Neurology</button>
            <button class="btn btn-default filter-button btng" data-filter="irrigation">Laboratry</button>
        </div>
        <br/>



            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe">
                <img src="assets/images/gallery/gallery_01.jpg" class="img-responsive">
            </div>

            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter sprinkle">
                <img src="assets/images/gallery/gallery_02.jpg" class="img-responsive">
            </div>

            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe">
                <img src="assets/images/gallery/gallery_03.jpg" class="img-responsive">
            </div>

            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter irrigation">
                <img src="assets/images/gallery/gallery_04.jpg" class="img-responsive">
            </div>

            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter spray">
                <img src="assets/images/gallery/gallery_05.jpg" class="img-responsive">
            </div>

          

            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter spray">
                <img src="assets/images/gallery/gallery_06.jpg" class="img-responsive">
            </div>

        </div>
    </div>
       
       
       </div>
        <!-- ######## Gallery End ####### -->
    
    
     <!--  ************************* Contact Us Starts Here ************************** -->
    
 
    
    
    
    
    <!-- ################# Footer Starts Here#######################--->


    <footer class="footer">
        <div class="container">
            <div class="row">
       
                <div class="col-md-6 col-sm-12">
                    <h2>Useful Links</h2>
                    <ul class="list-unstyled link-list">
                        <li><a ui-sref="about" href="#about">About us</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="portfolio" href="#services">Services</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="products" href="#logins">Logins</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="gallery" href="#gallery">Gallery</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="contact" href="#contact">Contact us</a><i class="fa fa-angle-right"></i></li>
                    </ul>
                </div>
                <div class="col-md-6 col-sm-12 map-img">
                    <h2>Contact Us</h2>
                    <address class="md-margin-bottom-40">

<?php
$ret=mysqli_query($con,"select * from tblpage where PageType='contactus' ");
while ($row=mysqli_fetch_array($ret)) {
?>


                        <?php  echo $row['PageDescription'];?> <br>
                        Phone: <?php  echo $row['MobileNumber'];?> <br>
                        Email: <a href="mailto:<?php  echo $row['Email'];?>" class=""><?php  echo $row['Email'];?></a><br>
                        Timing: <?php  echo $row['OpenningTime'];?>
                    </address>

        <?php } ?>





                </div>
            </div>
        </div>
        

    </footer>
    <div class="copy">
            <div class="container">
         Hospital Management System
                
     
            </div>

        </div>
    
    </body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/plugins/scroll-nav/js/jquery.easing.min.js"></script>
<script src="assets/plugins/scroll-nav/js/scrolling-nav.js"></script>
<script src="assets/plugins/scroll-fixed/jquery-scrolltofixed-min.js"></script>

<script src="assets/js/script.js"></script>

<script>
    // jQuery script to handle menu item click
    $(document).ready(function(){
        $('.menu-item').click(function(){
            // Remove active class from all menu items
            $('.menu-item').removeClass('active');
            // Add active class to the clicked menu item
            $(this).addClass('active');
        });
    });
</script>

</html>